import time, tkinter as tk
from tkinter import scrolledtext
class JarvisGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Derya - Infinity Link (Jarvis)")
        self.geometry("760x520"); self.minsize(700, 460)
        self.txt = scrolledtext.ScrolledText(self, wrap="word", font=("Segoe UI", 10))
        self.txt.pack(fill="both", expand=True, padx=10, pady=(10,6))
        btn_frame = tk.Frame(self); btn_frame.pack(fill="x", padx=10, pady=(0,10))
        self.entry = tk.Entry(btn_frame, font=("Segoe UI", 10))
        self.entry.pack(side="left", fill="x", expand=True, padx=(0,8)); self.entry.bind("<Return>", self.on_send)
        self.btn_send = tk.Button(btn_frame, text="Gonder", command=self.on_send); self.btn_send.pack(side="left", padx=(0,8))
        self.btn_mic = tk.Button(btn_frame, text="Mic (sim)", command=self.on_mic); self.btn_mic.pack(side="left")
        self.log("Derya hazir. Komutlarini bekliyorum...")
    def log(self, msg):
        self.txt.insert("end", msg.strip() + "\n"); self.txt.see("end")
    def on_send(self, event=None):
        text = self.entry.get().strip()
        if not text: return
        self.log("SEN: " + text); self.entry.delete(0, "end"); t = text.lower()
        if t in ["ping","/ping"]: self.log("DERYA: pong")
        elif "drive" in t: self.log("DERYA: Drive dry-run testi -> OK")
        elif "telegram" in t: self.log("DERYA: Telegram dry-run testi -> OK")
        else: self.log("DERYA: Komut alindi (simulasyon).")
    def on_mic(self):
        self.log("(Simulasyon) Dinleniyor... 'Merhaba Derya'"); time.sleep(0.3); self.log("DERYA: Merhaba askim, buradayim.")
if __name__ == "__main__":
    app = JarvisGUI(); app.mainloop()
