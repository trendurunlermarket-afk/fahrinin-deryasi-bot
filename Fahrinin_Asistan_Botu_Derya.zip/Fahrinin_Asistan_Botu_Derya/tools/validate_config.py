import json, sys, re
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
cfg  = ROOT / "config"
def warn(msg): print("INFO:", msg)
def fail(msg): print("ERROR:", msg); sys.exit(1)
def ok(msg): print("OK:", msg)
def check_placeholders(text, path):
    bad = re.findall(r"YOUR_[A-Z0-9_]+", text)
    if bad: fail(f"{path}: yer tutucular doldurulmamış: {sorted(set(bad))}")
def main():
    if not cfg.exists(): fail("config dizini bulunamadı")
    tele = cfg / "tele_config.yaml"; gdrv = cfg / "drive_creds.json"; metr = cfg / "metricool_connect.yaml"
    for p in [tele, gdrv]:
        if not p.exists(): fail(f"eksik dosya: {p}")
        txt = p.read_text(encoding="utf-8")
        if not txt.strip(): fail(f"{p}: boş dosya")
    check_placeholders(tele.read_text(encoding="utf-8"), tele)
    data = json.loads(gdrv.read_text(encoding="utf-8"))
    inst = data.get("installed", {})
    need = ["client_id","project_id","auth_uri","token_uri","client_secret","redirect_uris"]
    miss = [k for k in need if k not in inst]
    if miss: fail(f"drive_creds.json: installed.{miss} eksik")
    if not inst.get("client_secret"): fail("drive_creds.json: client_secret boş")
    if str(inst.get("client_secret","")).startswith("PASTE_"): warn("drive_creds.json: client_secret henüz yerleştirilmemiş. (Devam edilebilir)")
    if metr.exists() and "enabled: false" in metr.read_text(encoding="utf-8"):
        print("INFO: Metricool devre dışı (enabled: false).")
    ok("Tüm kontroller geçti. Yapılandırmalar hazır görünüyor!")
if __name__ == "__main__": main()
