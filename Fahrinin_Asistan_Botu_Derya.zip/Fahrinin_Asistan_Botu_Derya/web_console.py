from http.server import BaseHTTPRequestHandler, HTTPServer
import json, urllib.parse
MESSAGES = []
HTML = '''<!doctype html>
<html><head><meta charset="utf-8"><title>Derya - Infinity Link (Mobil Konsol)</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Segoe UI,system-ui,Arial;margin:0;background:#0b0f14;color:#e8eef5}
.wrap{max-width:900px;margin:0 auto;padding:16px}
h1{font-size:20px;margin:0 0 12px}
#log{border:1px solid #2a3340;background:#111826;height:50vh;overflow:auto;padding:10px;border-radius:8px}
.line{margin:4px 0}
.row{display:flex;gap:8px;margin-top:10px}
input,button{font-size:16px;padding:10px;border-radius:8px;border:1px solid #2a3340;background:#0f1622;color:#e8eef5}
button{cursor:pointer}
footer{opacity:.7;margin-top:10px;font-size:12px}
</style></head>
<body><div class="wrap">
<h1>Derya - Infinity Link (Mobil Konsol)</h1>
<div id="log"></div>
<div class="row"><input id="msg" placeholder="Komut yaz... (or: ping, drive, telegram)" style="flex:1"><button onclick="send()">Gonder</button></div>
<footer>Telefon ve PC senkron demodur.</footer>
</div>
<script>
async function refresh(){const r=await fetch('/messages'); const data=await r.json(); const log=document.getElementById('log'); log.innerHTML=''; data.forEach(x=>{const div=document.createElement('div'); div.className='line'; div.textContent=x; log.appendChild(div);}); log.scrollTop=log.scrollHeight;}
async function send(){const v=document.getElementById('msg').value; if(!v) return; await fetch('/say',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'q='+encodeURIComponent(v)}); document.getElementById('msg').value=''; refresh();}
setInterval(refresh, 1000); refresh();
</script></body></html>'''
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path.startswith("/index"):
            self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8"); self.end_headers(); self.wfile.write(HTML.encode("utf-8"))
        elif self.path.startswith("/messages"):
            self.send_response(200); self.send_header("Content-Type","application/json"); self.end_headers(); self.wfile.write(json.dumps(MESSAGES[-500:]).encode("utf-8"))
        else:
            self.send_response(404); self.end_headers()
    def do_POST(self):
        if self.path.startswith("/say"):
            length = int(self.headers.get("Content-Length","0")); body = self.rfile.read(length).decode("utf-8")
            q = urllib.parse.parse_qs(body).get("q",[""])[0].strip()
            if q:
                MESSAGES.append("USER: " + q); t = q.lower()
                if t in ["ping","/ping"]: MESSAGES.append("DERYA: pong")
                elif "drive" in t: MESSAGES.append("DERYA: Drive dry-run testi -> OK")
                elif "telegram" in t: MESSAGES.append("DERYA: Telegram dry-run testi -> OK")
                else: MESSAGES.append("DERYA: Komut alindi (simulasyon).")
            self.send_response(204); self.end_headers()
        else:
            self.send_response(404); self.end_headers()
if __name__ == "__main__":
    port = 8080
    print("[WebConsole] http://localhost:%d adresinde calisiyor... (Ayni agdaki telefonundan da IP:8080)" % port)
    HTTPServer(("0.0.0.0", port), H).serve_forever()
