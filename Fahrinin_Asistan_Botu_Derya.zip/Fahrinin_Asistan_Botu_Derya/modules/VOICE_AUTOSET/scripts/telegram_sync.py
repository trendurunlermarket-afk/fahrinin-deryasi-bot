print('Telegram dry-run OK')
