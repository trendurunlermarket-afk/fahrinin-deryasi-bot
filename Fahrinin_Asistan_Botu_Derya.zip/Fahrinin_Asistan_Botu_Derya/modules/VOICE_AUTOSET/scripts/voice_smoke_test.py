print('Voice smoke OK')
