AUTO DEPLOY DERYA — Tek Tıklamalık Yardım Paketi (TR/EN)
=======================================================
A) En Kolay Yol — GitHub UI ile sadece Dockerfile ekle
1) GitHub repo: https://github.com/<ACCOUNT>/<REPO>
2) “Add file” → “Upload files” → bu klasördeki `Dockerfile` dosyasını yükle → “Commit changes”
3) Render: https://dashboard.render.com/web/new
   - Source: GitHub → repo’nu seç
   - Language: Docker
   - Branch: main
   - Region: EU (Frankfurt) önerilir
   - Instance Type: Starter (24/7)
   - En altta “Deploy Web Service”

B) Windows — Tek Tık ile Dockerfile oluştur
1) Repo’yu bilgisayara indir ve aç.
2) `scripts\ADD_DOCKERFILE.cmd` dosyasını repo klasörüne kopyala ve çift tıkla.
3) (Git yüklüyse) CMD’de:
   git add Dockerfile
   git commit -m "Add Dockerfile for Render"
   git push origin main

Notlar
- requirements.txt varsa kullanılır; yoksa atlanır.
- Varsayılan komut: `web_console.py` → yoksa `app.py` → yoksa basit HTTP fallback.
